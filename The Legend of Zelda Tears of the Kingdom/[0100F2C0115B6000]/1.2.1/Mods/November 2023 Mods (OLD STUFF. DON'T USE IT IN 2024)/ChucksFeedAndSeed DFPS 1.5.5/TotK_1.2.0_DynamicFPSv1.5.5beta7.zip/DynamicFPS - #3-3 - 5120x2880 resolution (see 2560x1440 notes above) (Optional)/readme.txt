Optional extra to make DynamicFPS change the game resolution for you.
Make sure to also enable the main DynamicFPS mod marked (Required) for this to be active.